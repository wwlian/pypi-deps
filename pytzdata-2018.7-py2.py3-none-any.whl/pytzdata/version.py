# -*- coding: utf-8 -*-

VERSION = "2018.7"

OLSON_VERSION = "2018g"
