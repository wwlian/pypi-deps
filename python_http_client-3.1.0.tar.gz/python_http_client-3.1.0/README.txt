|SendGrid Logo|

.. |SendGrid Logo| image:: https://uiux.s3.amazonaws.com/2016-logos/email-logo%402x.png
   :target: https://www.sendgrid.com

**Quickly and easily access any RESTful or RESTful-like API.**

If you are looking for the SendGrid API client library, please see `this
repo <https://github.com/sendgrid/sendgrid-python>`__.

Table of Contents
=================

-  `Installation <#installation>`__
-  `Quick Start <#quick-start>`__
-  `Usage <#usage>`__
-  `Roadmap <#roadmap>`__
-  `How to Contribute <#contribute>`__
-  `Local set up <#local_setup>`__
-  `Troubleshooting <#troubleshooting>`__
-  `Announcements <#announcements>`__
-  `Thanks <#thanks>`__
-  `About <#about>`__
-  `License <#license>`__

 # Installation

Prerequisites
-------------

-  Python version 2.6, 2.7, 3.4, 3.5 or 3.6

Install Package
---------------

.. code:: bash

    pip install python_http_client

or

.. code:: bash

    easy_install python_http_client

API Key
-------

Store your SendGrid API key in a .env file

.. code:: bash

    cp .env_sample .env

Edit the ``.env`` file and add your API key.

 # Quick Start

Here is a quick example:

``GET /your/api/{param}/call``

.. code:: python

    import python_http_client
    global_headers = {"Authorization": "Basic XXXXXXX"}
    client = Client(host='base_url', request_headers=global_headers)
    client.your.api._(param).call.get()
    print response.status_code
    print response.headers
    print response.body

``POST /your/api/{param}/call`` with headers, query parameters and a
request body with versioning.

.. code:: python

    import python_http_client
    global_headers = {"Authorization": "Basic XXXXXXX"}
    client = Client(host='base_url', request_headers=global_headers)
    query_params={"hello":0, "world":1}
    request_headers={"X-Test": "test"}
    data={"some": 1, "awesome": 2, "data": 3}
    response = client.your.api._(param).call.post(request_body=data,
                                                  query_params=query_params,
                                                  request_headers=request_headers)
    print response.status_code
    print response.headers
    print response.body

 # Usage

-  `Example
   Code <https://github.com/sendgrid/python-http-client/tree/master/examples>`__

 # Roadmap

If you are interested in the future direction of this project, please
take a look at our
`milestones <https://github.com/sendgrid/python-http-client/milestones>`__.
We would love to hear your feedback.

 # How to Contribute

We encourage contribution to our projects, please see our
`CONTRIBUTING <https://github.com/sendgrid/python-http-client/blob/master/CONTRIBUTING.md>`__
guide for details.

Quick links:

-  `Feature
   Request <https://github.com/sendgrid/python-http-client/blob/master/CONTRIBUTING.md#feature-request>`__
-  `Bug
   Reports <https://github.com/sendgrid/python-http-client/blob/master/CONTRIBUTING.md#submit-a-bug-report>`__
-  `Sign the CLA to Create a Pull
   Request <https://github.com/sendgrid/python-http-client/blob/master/CONTRIBUTING.md#cla>`__
-  `Improvements to the
   Codebase <https://github.com/sendgrid/python-http-client/blob/master/CONTRIBUTING.md#improvements-to-the-codebase>`__
-  `Review Pull
   Requests <https://github.com/sendgrid/python-http-client/blob/master/CONTRIBUTING.md#code-reviews>`__

Local Setup of the project
==========================

The simplest local development workflow is by using docker.

    Steps

1. Install Docker
2. Run ``docker-compose build`` (This builds the container)
3. Run ``docker-compose up`` (This runs tests by default)

 # Troubleshooting

Please see our `troubleshooting
guide <https://github.com/sendgrid/python-http-client/blob/master/TROUBLESHOOTING.md>`__
for any issues.

 # Announcements

All updates to this project is documented in our
`CHANGELOG <https://github.com/sendgrid/python-http-client/blob/master/CHANGELOG.md>`__.

 # Thanks

We were inspired by the work done on
`birdy <https://github.com/inueni/birdy>`__ and
`universalclient <https://github.com/dgreisen/universalclient>`__.

 # About

python-http-client is guided and supported by the SendGrid `Developer
Experience Team <mailto:dx@sendgrid.com>`__.

python-http-client is maintained and funded by SendGrid, Inc. The names
and logos for python-http-client are trademarks of SendGrid, Inc.

 # License

`The MIT License (MIT) <LICENSE.txt>`__

.. |BuildStatus| image:: https://travis-ci.org/sendgrid/python-http-client.svg?branch=master
   :target: https://travis-ci.org/sendgrid/python-http-client
.. |Email Notifications Badge| image:: https://dx.sendgrid.com/badge/python
   :target: https://dx.sendgrid.com/newsletter/python
.. |Twitter Follow| image:: https://img.shields.io/twitter/follow/sendgrid.svg?style=social&label=Follow
   :target: https://twitter.com/sendgrid
.. |Codecov branch| image:: https://img.shields.io/codecov/c/github/sendgrid/python-http-client/master.svg?style=flat-square&label=Codecov+Coverage
   :target: https://codecov.io/gh/sendgrid/python-http-client
.. |Code Climate| image:: https://codeclimate.com/github/sendgrid/python-http-client/badges/gpa.svg
   :target: https://codeclimate.com/github/sendgrid/python-http-client
.. |GitHub contributors| image:: https://img.shields.io/github/contributors/sendgrid/python-http-client.svg
   :target: https://github.com/sendgrid/python-http-client/graphs/contributors
.. |MIT licensed| image:: https://img.shields.io/badge/license-MIT-blue.svg
   :target: ./LICENSE.txt
