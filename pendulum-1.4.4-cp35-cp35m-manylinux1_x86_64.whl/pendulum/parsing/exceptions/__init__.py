# -*- coding: utf-8 -*-


class ParserError(ValueError):

    pass
