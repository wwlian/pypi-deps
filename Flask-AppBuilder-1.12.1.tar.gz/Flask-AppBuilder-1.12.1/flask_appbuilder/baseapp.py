from .base import AppBuilder

"""
    This is for retro compatibility
"""
BaseApp = AppBuilder
