.. module:: nvd3.multiBarChart

.. _multiBarChart-model:

:class:`multiBarChart`
----------------------

.. autoclass:: multiBarChart
    :noindex:

See the HTML source code of this page, to see the underlying javascript.
