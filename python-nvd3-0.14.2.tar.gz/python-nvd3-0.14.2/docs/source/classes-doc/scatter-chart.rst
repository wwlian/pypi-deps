.. module:: nvd3.scatterChart

.. _scatterChart-model:

:class:`scatterChart`
---------------------

.. autoclass:: scatterChart
    :noindex:

See the HTML source code of this page, to see the underlying javascript.
