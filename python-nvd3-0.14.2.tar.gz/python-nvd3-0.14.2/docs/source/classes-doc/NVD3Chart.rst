.. module:: nvd3.NVD3Chart

.. _NVD3Chart-model:

:class:`NVD3Chart`
------------------

.. autoclass:: nvd3.NVD3Chart.NVD3Chart
    :members:
    :undoc-members:

    ..  automethod:: __init__


