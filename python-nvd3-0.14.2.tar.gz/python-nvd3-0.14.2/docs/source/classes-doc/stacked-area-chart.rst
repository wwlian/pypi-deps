.. module:: nvd3.stackedAreaChart

.. _stackedAreaChart-model:

:class:`stackedAreaChart`
-------------------------

.. autoclass:: stackedAreaChart
    :noindex:

See the HTML source code of this page, to see the underlying javascript.
