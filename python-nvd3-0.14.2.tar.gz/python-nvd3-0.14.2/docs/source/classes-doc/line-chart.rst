.. module:: nvd3.lineChart

.. _lineChart-model:

:class:`lineChart`
------------------

.. autoclass:: lineChart
    :noindex:

See the HTML source code of this page, to see the underlying javascript.
