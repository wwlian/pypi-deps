.. module:: nvd3.lineWithFocusChart

.. _lineWithFocusChart-model:

:class:`lineWithFocusChart`
---------------------------

.. autoclass:: lineWithFocusChart
    :noindex:

See the HTML source code of this page, to see the underlying javascript.
