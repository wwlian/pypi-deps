# -*- coding: utf-8 -*-

VERSION = "2019.1"

OLSON_VERSION = "2019a"
